# Page Curl Comics

An Android comic reader for **.cbz** (ZIP) and **.cbr** (RAR) files with a Google Play Books style page curl.

## Getting the APK

### Option A: build it in the cloud (no Android Studio needed)
1. Create a new GitHub repository and upload everything in this folder (keep the `.github` folder).
2. Open the repository's **Actions** tab, choose **Build APK**, and click **Run workflow** (it also runs on every push).
3. When it finishes (a few minutes), open the run and download the **PageCurlComics-debug-apk** artifact. Unzip it to get `app-debug.apk`.
4. Copy the APK to your phone and tap it. If Android asks, allow "Install unknown apps" for your file manager or browser.

### Option B: Android Studio
1. Open this folder in Android Studio and let Gradle sync.
2. **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. The APK is at `app/build/outputs/apk/debug/app-debug.apk`.

### Option C: command line
With the Android SDK installed (platform 35), Java 17 and Gradle 8.10+: `gradle :app:assembleDebug`

## Using it
- **Open file** picks a .cbz/.cbr. You can also open comics straight from a file manager or browser.
- Drag from the right edge to curl forward, from the left edge to curl back. Tap the right or left side of the page to turn it with the same animation.
- Tap the middle to show or hide the page slider. Volume keys also turn pages.
- **LTR / RTL** (top bar) switches to right-to-left reading for manga. The curl mirrors too.
- Your page is remembered per comic. Long-press a cover in the library to remove it.

## Notes
- Format is detected from the file contents, so a .cbr that is really a ZIP (common) still opens.
- .cbr support uses the `junrar` library: RAR 4 and earlier work, **RAR5 archives are not supported**. Re-save those as .cbz.
- RAR pages are extracted to cache on first open (a progress message shows), so big .cbr files take a moment.
- Not included yet: pinch-zoom, two-page landscape spreads, .cb7/.cbt.
