package com.example.pagecurlcomics

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.github.junrar.Archive
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipFile

/** A readable comic: an ordered list of page images. */
interface ComicSource : Closeable {
    val pageCount: Int

    /** Decodes a page, downsampled so it is still at least [maxW] x [maxH] where possible. */
    fun decode(index: Int, maxW: Int, maxH: Int): Bitmap?
}

private val IMAGE_EXTENSIONS = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

fun isImageName(name: String): Boolean {
    val base = name.substringAfterLast('/').substringAfterLast('\\')
    if (base.startsWith(".") || name.contains("__MACOSX")) return false
    return base.substringAfterLast('.', "").lowercase() in IMAGE_EXTENSIONS
}

/** "page2" sorts before "page10". */
object NaturalOrder : Comparator<String> {
    override fun compare(a: String, b: String): Int {
        var i = 0
        var j = 0
        while (i < a.length && j < b.length) {
            val ca = a[i]
            val cb = b[j]
            if (ca.isDigit() && cb.isDigit()) {
                var ei = i
                while (ei < a.length && a[ei].isDigit()) ei++
                var ej = j
                while (ej < b.length && b[ej].isDigit()) ej++
                val na = a.substring(i, ei).trimStart('0')
                val nb = b.substring(j, ej).trimStart('0')
                if (na.length != nb.length) return na.length - nb.length
                val c = na.compareTo(nb)
                if (c != 0) return c
                i = ei
                j = ej
            } else {
                if (ca != cb) return ca.compareTo(cb)
                i++
                j++
            }
        }
        return (a.length - i) - (b.length - j)
    }
}

fun decodeSampled(open: () -> InputStream, maxW: Int, maxH: Int): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    open().use { BitmapFactory.decodeStream(it, null, bounds) }
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
    var sample = 1
    while (bounds.outWidth / (sample * 2) >= maxW && bounds.outHeight / (sample * 2) >= maxH) {
        sample *= 2
    }
    val opts = BitmapFactory.Options().apply {
        inSampleSize = sample
        inPreferredConfig = Bitmap.Config.ARGB_8888
    }
    return open().use { BitmapFactory.decodeStream(it, null, opts) }
}

/** .cbz (ZIP): pages are read straight out of the archive. */
class ZipSource(file: File) : ComicSource {
    private val zip: ZipFile = try {
        ZipFile(file)
    } catch (e: Exception) {
        // Some archives use legacy (non-UTF-8) file names.
        ZipFile(file, Charsets.ISO_8859_1)
    }

    private val entries = zip.entries().asSequence()
        .filter { !it.isDirectory && isImageName(it.name) }
        .sortedWith(compareBy(NaturalOrder) { it.name.lowercase() })
        .toList()

    override val pageCount: Int get() = entries.size

    override fun decode(index: Int, maxW: Int, maxH: Int): Bitmap? = try {
        decodeSampled({ zip.getInputStream(entries[index]) }, maxW, maxH)
    } catch (e: Exception) {
        null
    }

    override fun close() {
        try { zip.close() } catch (_: IOException) {}
    }
}

/** Pages that were already extracted to individual files (used for .cbr). */
class FileListSource(private val files: List<File>) : ComicSource {
    override val pageCount: Int get() = files.size

    override fun decode(index: Int, maxW: Int, maxH: Int): Bitmap? = try {
        decodeSampled({ files[index].inputStream() }, maxW, maxH)
    } catch (e: Exception) {
        null
    }

    override fun close() {}
}

/**
 * .cbr (RAR): RAR archives are often "solid", which makes random access unreliable,
 * so the images are extracted once, in order, into the cache folder.
 */
object RarExtractor {
    fun extract(archiveFile: File, outDir: File, onProgress: (Int) -> Unit): List<File> {
        outDir.deleteRecursively()
        outDir.mkdirs()
        val extracted = ArrayList<Pair<String, File>>()
        try {
            Archive(archiveFile).use { archive ->
                var h = archive.nextFileHeader()
                var n = 0
                while (h != null) {
                    val header = h
                    if (header.isEncrypted) throw IOException("This archive is password protected.")
                    val name = header.fileName.replace('\\', '/')
                    if (!header.isDirectory && isImageName(name)) {
                        val ext = name.substringAfterLast('.').lowercase()
                        val out = File(outDir, "%05d.%s".format(n++, ext))
                        FileOutputStream(out).use { archive.extractFile(header, it) }
                        extracted.add(name to out)
                        onProgress(n)
                    }
                    h = archive.nextFileHeader()
                }
            }
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            if (e.javaClass.simpleName.contains("V5")) {
                throw IOException("This is a RAR5 archive, which isn't supported yet. Re-save it as .cbz or classic RAR.")
            }
            throw IOException("Couldn't read this RAR archive (${e.javaClass.simpleName}).")
        }
        return extracted
            .sortedWith(compareBy(NaturalOrder) { it.first.lowercase() })
            .map { it.second }
    }
}
