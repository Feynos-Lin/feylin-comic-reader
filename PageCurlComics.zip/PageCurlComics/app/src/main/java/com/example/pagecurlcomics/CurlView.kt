package com.example.pagecurlcomics

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.util.LruCache
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * A single-page comic view with a Google Play Books style page curl.
 *
 * The turning sheet is folded along the perpendicular bisector between a page corner and the
 * finger. The part past the fold is cut away (revealing the next page), and its mirror image is
 * drawn back over the page as the paper's reverse side.
 *
 * All geometry is computed as if reading left-to-right. For right-to-left (manga) mode the
 * canvas is mirrored and the bitmaps are flipped back, so everything else stays the same.
 */
class CurlView(context: Context) : View(context) {

    interface Listener {
        fun onPageChanged(index: Int)
        fun onCenterTap()
        fun onTurnStarted()
    }

    var listener: Listener? = null

    var rtl: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var pageCount = 0
        private set
    var currentIndex = 0
        private set

    private enum class Mode { IDLE, DRAGGING, ANIMATING }

    private data class Pt(val x: Float, val y: Float)

    private var source: ComicSource? = null
    private val loader = Executors.newFixedThreadPool(2)
    private val cache = LruCache<Int, Bitmap>(6)
    private val loading = HashSet<Int>()
    private var generation = 0

    private val pageBg = Color.rgb(16, 16, 16)
    private val paperTint = Color.argb(205, 236, 230, 214)
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val gradientPaint = Paint()
    private val flipMatrix = Matrix()

    // Curl state
    private var mode = Mode.IDLE
    private var forward = true
    private var sheetIndex = 0
    private var underIndex = 0
    private var cornerY = 0f
    private var tx = 0f
    private var ty = 0f
    private var anim: ValueAnimator? = null

    // Touch state
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private var velocity: VelocityTracker? = null
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    fun setSource(src: ComicSource, startIndex: Int) {
        source = src
        pageCount = src.pageCount
        generation++
        cache.evictAll()
        loading.clear()
        anim?.cancel()
        mode = Mode.IDLE
        currentIndex = startIndex.coerceIn(0, maxOf(0, pageCount - 1))
        prefetch()
        invalidate()
        listener?.onPageChanged(currentIndex)
    }

    fun shutdown() {
        anim?.cancel()
        loader.shutdownNow()
    }

    fun goTo(index: Int) {
        if (pageCount == 0) return
        anim?.cancel()
        mode = Mode.IDLE
        currentIndex = index.coerceIn(0, pageCount - 1)
        prefetch()
        invalidate()
        listener?.onPageChanged(currentIndex)
    }

    /** Animated page turn, used by taps and the volume keys. */
    fun turn(forwardDirection: Boolean, fromTopHalf: Boolean = false) {
        if (pageCount == 0 || mode != Mode.IDLE || width == 0) return
        if (forwardDirection && currentIndex >= pageCount - 1) return
        if (!forwardDirection && currentIndex <= 0) return
        val w = width.toFloat()
        val h = height.toFloat()
        beginTurn(forwardDirection, if (fromTopHalf) 0f else h)
        val sign = if (cornerY == 0f) 1f else -1f
        listener?.onTurnStarted()
        if (forwardDirection) {
            runAnim(w - 1f, cornerY, -1.5f * w, cornerY, sign * h * 0.22f, 420L, true)
        } else {
            runAnim(-1.5f * w, cornerY, w - 1f, cornerY, sign * h * 0.22f, 420L, true)
        }
    }

    // ---------------------------------------------------------------- page loading

    private fun prefetch() {
        requestPage(currentIndex)
        requestPage(currentIndex + 1)
        requestPage(currentIndex - 1)
        requestPage(currentIndex + 2)
    }

    private fun requestPage(i: Int) {
        val src = source ?: return
        if (i < 0 || i >= pageCount || width == 0 || height == 0) return
        if (cache.get(i) != null || i in loading) return
        loading.add(i)
        val gen = generation
        val w = width
        val h = height
        loader.execute {
            val bmp = try {
                compose(src.decode(i, w, h), w, h)
            } catch (e: OutOfMemoryError) {
                null
            } catch (e: Exception) {
                null
            }
            post {
                loading.remove(i)
                if (gen == generation && bmp != null) {
                    cache.put(i, bmp)
                    invalidate()
                }
            }
        }
    }

    /** Fits the decoded image into a view-sized bitmap, centered on a dark background. */
    private fun compose(src: Bitmap?, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(pageBg)
        if (src != null) {
            val scale = min(w.toFloat() / src.width, h.toFloat() / src.height)
            val dw = src.width * scale
            val dh = src.height * scale
            val left = (w - dw) / 2f
            val top = (h - dh) / 2f
            c.drawBitmap(src, null, RectF(left, top, left + dw, top + dh), paint)
            src.recycle()
        }
        return out
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        flipMatrix.setScale(-1f, 1f, w / 2f, 0f)
        generation++
        cache.evictAll()
        loading.clear()
        anim?.cancel()
        mode = Mode.IDLE
        prefetch()
    }

    // ---------------------------------------------------------------- drawing

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(pageBg)
        canvas.save()
        if (rtl) canvas.scale(-1f, 1f, width / 2f, 0f)
        if (mode == Mode.IDLE) {
            drawBmp(canvas, cache.get(currentIndex))
        } else {
            drawCurl(canvas, cache.get(sheetIndex), cache.get(underIndex))
        }
        canvas.restore()
    }

    private fun drawBmp(c: Canvas, b: Bitmap?) {
        if (b == null) return
        if (rtl) c.drawBitmap(b, flipMatrix, paint) else c.drawBitmap(b, 0f, 0f, paint)
    }

    private fun drawCurl(c: Canvas, sheet: Bitmap?, under: Bitmap?) {
        val w = width.toFloat()
        val h = height.toFloat()
        val dx = w - tx
        val dy = cornerY - ty
        val len = hypot(dx, dy)
        if (len < 1.5f) {
            drawBmp(c, sheet)
            return
        }
        // (nx, ny) points from the finger toward the corner; the corner side is "cut".
        val nx = dx / len
        val ny = dy / len
        val mx = (w + tx) / 2f
        val my = (cornerY + ty) / 2f

        val rect = listOf(Pt(0f, 0f), Pt(w, 0f), Pt(w, h), Pt(0f, h))
        val keep = clipHalf(rect, mx, my, nx, ny, false)
        val cut = clipHalf(rect, mx, my, nx, ny, true)

        // 1. The page underneath, with the curl's shadow falling on it.
        drawBmp(c, under)
        if (cut.size >= 3) {
            c.save()
            c.clipPath(polyPath(cut))
            gradientPaint.shader = LinearGradient(
                mx, my, mx + nx * 90f, my + ny * 90f,
                Color.argb(150, 0, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP,
            )
            c.drawRect(0f, 0f, w, h, gradientPaint)
            c.restore()
        }

        // 2. The part of the turning page that is still flat.
        if (keep.size >= 3) {
            c.save()
            c.clipPath(polyPath(keep))
            drawBmp(c, sheet)
            c.restore()
        }

        // 3. The curled-over part: the cut area mirrored across the fold, showing the paper's back.
        if (cut.size >= 3) {
            val mirrored = cut.map { reflect(it, mx, my, nx, ny) }
            c.save()
            c.clipPath(polyPath(mirrored))
            c.clipRect(0f, 0f, w, h)
            if (sheet != null) {
                val d = 2f * (mx * nx + my * ny)
                val m = Matrix()
                m.setValues(
                    floatArrayOf(
                        1f - 2f * nx * nx, -2f * nx * ny, d * nx,
                        -2f * nx * ny, 1f - 2f * ny * ny, d * ny,
                        0f, 0f, 1f,
                    )
                )
                if (rtl) m.preScale(-1f, 1f, w / 2f, 0f)
                c.drawBitmap(sheet, m, paint)
            }
            c.drawColor(paperTint)
            gradientPaint.shader = LinearGradient(
                mx, my, mx - nx * 110f, my - ny * 110f,
                Color.argb(130, 0, 0, 0), Color.TRANSPARENT, Shader.TileMode.CLAMP,
            )
            c.drawRect(0f, 0f, w, h, gradientPaint)
            c.restore()
        }
    }

    /** Keeps the part of [poly] on one side of the line through (mx, my) with normal (nx, ny). */
    private fun clipHalf(poly: List<Pt>, mx: Float, my: Float, nx: Float, ny: Float, keepPositive: Boolean): List<Pt> {
        val sign = if (keepPositive) 1f else -1f
        fun side(p: Pt) = ((p.x - mx) * nx + (p.y - my) * ny) * sign
        val out = ArrayList<Pt>()
        for (i in poly.indices) {
            val a = poly[i]
            val b = poly[(i + 1) % poly.size]
            val fa = side(a)
            val fb = side(b)
            if (fa >= 0f) out.add(a)
            if ((fa >= 0f) != (fb >= 0f)) {
                val t = fa / (fa - fb)
                out.add(Pt(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t))
            }
        }
        return out
    }

    private fun reflect(p: Pt, mx: Float, my: Float, nx: Float, ny: Float): Pt {
        val d = (p.x - mx) * nx + (p.y - my) * ny
        return Pt(p.x - 2f * d * nx, p.y - 2f * d * ny)
    }

    private fun polyPath(poly: List<Pt>): Path {
        val path = Path()
        poly.forEachIndexed { i, p -> if (i == 0) path.moveTo(p.x, p.y) else path.lineTo(p.x, p.y) }
        path.close()
        return path
    }

    // ---------------------------------------------------------------- turning

    /** Sets up which page curls and which is revealed. The corner is the top or bottom right. */
    private fun beginTurn(forwardDirection: Boolean, corner: Float) {
        forward = forwardDirection
        cornerY = corner
        sheetIndex = if (forwardDirection) currentIndex else currentIndex - 1
        underIndex = if (forwardDirection) currentIndex + 1 else currentIndex
        requestPage(sheetIndex)
        requestPage(underIndex)
    }

    private fun runAnim(
        fromX: Float, fromY: Float, toX: Float, toY: Float,
        arc: Float, duration: Long, tap: Boolean,
        commit: Boolean = true,
    ) {
        anim?.cancel()
        mode = Mode.ANIMATING
        tx = fromX
        ty = fromY
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = duration
        a.interpolator = if (tap) AccelerateDecelerateInterpolator() else DecelerateInterpolator(1.3f)
        a.addUpdateListener {
            val p = it.animatedValue as Float
            tx = fromX + (toX - fromX) * p
            ty = fromY + (toY - fromY) * p + arc * sin(Math.PI * p).toFloat()
            invalidate()
        }
        a.addListener(object : AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: Animator) {
                cancelled = true
            }

            override fun onAnimationEnd(animation: Animator) {
                if (!cancelled) finishTurn(commit)
            }
        })
        anim = a
        a.start()
    }

    private fun finishTurn(commit: Boolean) {
        if (commit) {
            currentIndex = if (forward) underIndex else sheetIndex
        }
        mode = Mode.IDLE
        prefetch()
        invalidate()
        if (commit) listener?.onPageChanged(currentIndex)
    }

    private fun updateDrag(gx: Float, gy: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        val dx = gx - downX
        tx = if (forward) (w - 1f + dx * 1.6f) else (-1.5f * w + dx * 2.0f)
        tx = tx.coerceIn(-1.5f * w, w - 1f)
        ty = (cornerY + (gy - downY) * 0.8f).coerceIn(-0.2f * h, 1.2f * h)
        invalidate()
    }

    private fun releaseDrag(vx: Float, cancelled: Boolean) {
        val w = width.toFloat()
        val commit = if (cancelled) {
            false
        } else if (forward) {
            (tx < w * 0.5f || vx < -900f) && vx < 900f
        } else {
            (tx > -w * 0.5f || vx > 900f) && vx > -900f
        }
        val toX = when {
            forward && commit -> -1.5f * w
            forward -> w - 1f
            commit -> w - 1f
            else -> -1.5f * w
        }
        val distance = abs(toX - tx) / w
        val duration = (240 + 180 * distance.coerceAtMost(1.5f)).toLong()
        runAnim(tx, ty, toX, cornerY, 0f, duration, false, commit)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (pageCount == 0) return true
        if (mode == Mode.ANIMATING) return true
        val gx = if (rtl) width - e.x else e.x
        val gy = e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = gx
                downY = gy
                downTime = e.eventTime
                velocity?.recycle()
                velocity = VelocityTracker.obtain().also { it.addMovement(e) }
            }

            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(e)
                if (mode == Mode.IDLE) {
                    val dx = gx - downX
                    val dy = gy - downY
                    if (abs(dx) > slop && abs(dx) > abs(dy) * 0.6f) {
                        val corner = if (downY < height / 2f) 0f else height.toFloat()
                        if (dx < 0 && currentIndex < pageCount - 1) {
                            beginTurn(true, corner)
                            mode = Mode.DRAGGING
                            listener?.onTurnStarted()
                        } else if (dx > 0 && currentIndex > 0) {
                            beginTurn(false, corner)
                            mode = Mode.DRAGGING
                            listener?.onTurnStarted()
                        }
                    }
                }
                if (mode == Mode.DRAGGING) updateDrag(gx, gy)
            }

            MotionEvent.ACTION_UP -> {
                velocity?.addMovement(e)
                velocity?.computeCurrentVelocity(1000)
                val rawVx = velocity?.xVelocity ?: 0f
                val vx = if (rtl) -rawVx else rawVx
                if (mode == Mode.DRAGGING) {
                    releaseDrag(vx, false)
                } else if (mode == Mode.IDLE &&
                    e.eventTime - downTime < 350 &&
                    abs(gx - downX) < slop * 2 && abs(gy - downY) < slop * 2
                ) {
                    handleTap(gx, gy)
                }
                velocity?.recycle()
                velocity = null
            }

            MotionEvent.ACTION_CANCEL -> {
                if (mode == Mode.DRAGGING) releaseDrag(0f, true)
                velocity?.recycle()
                velocity = null
            }
        }
        return true
    }

    private fun handleTap(gx: Float, gy: Float) {
        val w = width.toFloat()
        val top = gy < height / 2f
        when {
            gx > w * 0.65f -> turn(true, top)
            gx < w * 0.35f -> turn(false, top)
            else -> listener?.onCenterTap()
        }
    }
}
