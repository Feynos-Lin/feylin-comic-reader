package com.example.pagecurlcomics

import android.app.Activity
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

class ReaderActivity : Activity(), CurlView.Listener {

    private lateinit var curl: CurlView
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var pageLabel: TextView
    private lateinit var directionButton: Button
    private lateinit var status: TextView
    private lateinit var library: Library

    private var source: ComicSource? = null
    private var hash = ""
    private var title = ""
    private var uriString = ""
    private var rtl = false
    private var barsVisible = true

    private val prefs by lazy { getSharedPreferences("reader", MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        library = Library(this)
        rtl = prefs.getBoolean("rtl", false)

        if (Build.VERSION.SDK_INT >= 28) {
            val lp = window.attributes
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            window.attributes = lp
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        curl = CurlView(this).also {
            it.listener = this
            it.rtl = rtl
        }
        root.addView(curl, FrameLayout.LayoutParams(-1, -1))

        // Top bar: back, title, reading direction
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.argb(200, 0, 0, 0))
            setPadding(dp(8), dp(24), dp(8), dp(8))
        }
        topBar.addView(Button(this).apply {
            text = "←"
            setOnClickListener { finish() }
        })
        val titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(8), 0)
            tag = "title"
        }
        topBar.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        directionButton = Button(this).apply {
            setOnClickListener { setRtl(!rtl) }
        }
        topBar.addView(directionButton)
        root.addView(topBar, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))

        // Bottom bar: page slider
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(200, 0, 0, 0))
            setPadding(dp(16), dp(8), dp(16), dp(20))
        }
        pageLabel = TextView(this).apply {
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = 14f
        }
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) curl.goTo(progress)
            }

            override fun onStartTrackingTouch(bar: SeekBar) {}
            override fun onStopTrackingTouch(bar: SeekBar) {}
        })
        bottomBar.addView(pageLabel, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        bottomBar.addView(seek, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))

        status = TextView(this).apply {
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            textSize = 16f
            setPadding(dp(32), dp(32), dp(32), dp(32))
            text = "Opening…"
        }
        root.addView(status, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)
        applyRtlUi()
        hideSystemUi()
        openComic()
    }

    private fun openComic() {
        val uri = intent?.data
        if (uri == null) {
            finish()
            return
        }
        uriString = uri.toString()
        hash = BookStore.hashOf(uriString)
        title = BookStore.displayName(this, uri)
        topBar.findViewWithTag<TextView>("title").text = title

        Thread {
            try {
                val file = BookStore.ensureCached(this, uri, hash) { msg -> runOnUiThread { status.text = msg } }
                val src = BookStore.open(this, hash, file) { msg -> runOnUiThread { status.text = msg } }
                if (src.pageCount == 0) throw java.io.IOException("No images found in this archive.")
                BookStore.saveCoverIfMissing(this, hash, src)
                runOnUiThread { onOpened(src) }
            } catch (e: Throwable) {
                runOnUiThread { showError(e.message ?: "Couldn't open this comic.") }
            }
        }.start()
    }

    private fun onOpened(src: ComicSource) {
        if (isFinishing || isDestroyed) {
            src.close()
            return
        }
        source = src
        status.visibility = View.GONE
        val saved = library.get(hash)
        val start = (saved?.lastPage ?: 0).coerceIn(0, src.pageCount - 1)
        library.upsert(BookEntry(uriString, title, hash, start, src.pageCount, System.currentTimeMillis()))
        seek.max = maxOf(0, src.pageCount - 1)
        curl.setSource(src, start)
    }

    private fun showError(message: String) {
        status.text = message
        status.visibility = View.VISIBLE
    }

    // ---------------------------------------------------------------- CurlView.Listener

    override fun onPageChanged(index: Int) {
        val count = curl.pageCount
        pageLabel.text = "${index + 1} / $count"
        seek.progress = index
        library.get(hash)?.let {
            it.lastPage = index
            it.pageCount = count
            it.lastOpened = System.currentTimeMillis()
            library.upsert(it)
        }
    }

    override fun onCenterTap() = setBars(!barsVisible)

    override fun onTurnStarted() {
        if (barsVisible) setBars(false)
    }

    private fun setBars(visible: Boolean) {
        barsVisible = visible
        val v = if (visible) View.VISIBLE else View.GONE
        topBar.visibility = v
        bottomBar.visibility = v
    }

    private fun setRtl(value: Boolean) {
        rtl = value
        prefs.edit().putBoolean("rtl", value).apply()
        curl.rtl = value
        applyRtlUi()
    }

    private fun applyRtlUi() {
        directionButton.text = if (rtl) "RTL" else "LTR"
        seek.rotation = if (rtl) 180f else 0f
    }

    // ---------------------------------------------------------------- system UI and keys

    @Suppress("DEPRECATION")
    private fun hideSystemUi() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_DOWN -> { curl.turn(true); true }
            KeyEvent.KEYCODE_VOLUME_UP -> { curl.turn(false); true }
            else -> super.onKeyDown(keyCode, event)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        curl.shutdown()
        source?.close()
    }
}
