package com.example.pagecurlcomics

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var library: Library
    private lateinit var grid: GridView
    private lateinit var emptyView: TextView
    private val adapter = BookAdapter()
    private var books: List<BookEntry> = emptyList()
    private val covers = LruCache<String, Bitmap>(40)

    private companion object {
        const val REQUEST_OPEN = 42
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        library = Library(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121212"))
            fitsSystemWindows = true
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(16), dp(16), dp(8))
        }
        val title = TextView(this).apply {
            text = "Comics"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            setTypeface(typeface, Typeface.BOLD)
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(Button(this).apply {
            text = "Open file"
            setOnClickListener { pickFile() }
        })
        root.addView(header)

        val body = FrameLayout(this)
        grid = GridView(this).apply {
            numColumns = 3
            horizontalSpacing = dp(12)
            verticalSpacing = dp(16)
            setPadding(dp(16), dp(8), dp(16), dp(16))
            clipToPadding = false
            selector = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
            this.adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, position, _ -> openBook(books[position]) }
            setOnItemLongClickListener { _, _, position, _ ->
                confirmRemove(books[position])
                true
            }
        }
        body.addView(grid, FrameLayout.LayoutParams(-1, -1))
        emptyView = TextView(this).apply {
            text = "Tap \"Open file\" to pick a .cbz or .cbr comic."
            setTextColor(Color.parseColor("#9A9A9A"))
            gravity = Gravity.CENTER
            setPadding(dp(32), dp(32), dp(32), dp(32))
        }
        body.addView(emptyView, FrameLayout.LayoutParams(-1, -1))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        books = library.all()
        emptyView.visibility = if (books.isEmpty()) View.VISIBLE else View.GONE
        adapter.notifyDataSetChanged()
    }

    private fun pickFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf(
                    "application/vnd.comicbook+zip", "application/vnd.comicbook-rar",
                    "application/x-cbz", "application/x-cbr",
                    "application/zip", "application/x-rar-compressed", "application/vnd.rar",
                    "application/octet-stream",
                )
            )
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_OPEN)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_OPEN || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        startActivity(Intent(this, ReaderActivity::class.java).apply {
            this.data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }

    private fun openBook(book: BookEntry) {
        try {
            startActivity(Intent(this, ReaderActivity::class.java).apply {
                data = android.net.Uri.parse(book.uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open this comic.", Toast.LENGTH_LONG).show()
        }
    }

    private fun confirmRemove(book: BookEntry) {
        AlertDialog.Builder(this)
            .setTitle(book.title)
            .setMessage("Remove from your library? The file itself isn't deleted.")
            .setPositiveButton("Remove") { _, _ ->
                library.remove(book.hash)
                BookStore.coverFile(this, book.hash).delete()
                covers.remove(book.hash)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun cover(hash: String): Bitmap? {
        covers.get(hash)?.let { return it }
        val f: File = BookStore.coverFile(this, hash)
        if (!f.exists()) return null
        val bmp = BitmapFactory.decodeFile(f.path) ?: return null
        covers.put(hash, bmp)
        return bmp
    }

    private inner class BookAdapter : BaseAdapter() {
        override fun getCount() = books.size
        override fun getItem(position: Int) = books[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val book = books[position]
            val colWidth = maxOf(dp(80), (parent.width - dp(32) - dp(24)) / 3)

            val cell = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = AbsListViewParams(colWidth)
            }
            val image = ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.parseColor("#2A2A2A"))
                val bmp = cover(book.hash)
                if (bmp != null) setImageBitmap(bmp)
            }
            cell.addView(image, LinearLayout.LayoutParams(colWidth, (colWidth * 1.5f).toInt()))

            val name = TextView(this@MainActivity).apply {
                text = book.title
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setPadding(0, dp(6), 0, dp(2))
            }
            cell.addView(name)

            if (book.pageCount > 0) {
                val bar = ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = book.pageCount
                    progress = (book.lastPage + 1).coerceAtMost(book.pageCount)
                }
                cell.addView(bar, LinearLayout.LayoutParams(-1, dp(6)))
                cell.addView(TextView(this@MainActivity).apply {
                    text = "Page ${book.lastPage + 1} of ${book.pageCount}"
                    setTextColor(Color.parseColor("#9A9A9A"))
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    setPadding(0, dp(2), 0, 0)
                })
            }
            return cell
        }

        private fun AbsListViewParams(width: Int) =
            android.widget.AbsListView.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT)
    }
}
