package com.example.pagecurlcomics

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest

data class BookEntry(
    val uri: String,
    val title: String,
    val hash: String,
    var lastPage: Int,
    var pageCount: Int,
    var lastOpened: Long,
)

/** The "recent comics" list, kept in SharedPreferences. */
class Library(context: Context) {
    private val prefs = context.getSharedPreferences("library", Context.MODE_PRIVATE)

    fun all(): List<BookEntry> {
        val raw = prefs.getString("books", "[]") ?: "[]"
        val list = ArrayList<BookEntry>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    BookEntry(
                        o.getString("uri"), o.getString("title"), o.getString("hash"),
                        o.optInt("lastPage", 0), o.optInt("pageCount", 0), o.optLong("lastOpened", 0L),
                    )
                )
            }
        } catch (_: Exception) {
        }
        return list.sortedByDescending { it.lastOpened }
    }

    fun get(hash: String): BookEntry? = all().firstOrNull { it.hash == hash }

    fun upsert(entry: BookEntry) {
        val list = all().filter { it.hash != entry.hash }.toMutableList()
        list.add(entry)
        save(list)
    }

    fun remove(hash: String) = save(all().filter { it.hash != hash })

    private fun save(list: List<BookEntry>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject()
                    .put("uri", it.uri).put("title", it.title).put("hash", it.hash)
                    .put("lastPage", it.lastPage).put("pageCount", it.pageCount)
                    .put("lastOpened", it.lastOpened)
            )
        }
        prefs.edit().putString("books", arr.toString()).apply()
    }
}

/** Copies comics into app storage, detects their real format, and opens them. */
object BookStore {
    private const val MAX_CACHED_BOOKS = 4

    fun hashOf(uri: String): String {
        val digest = MessageDigest.getInstance("SHA-1").digest(uri.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }.take(16)
    }

    fun displayName(context: Context, uri: Uri): String {
        var name: String? = null
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) name = it.getString(0)
            }
        } catch (_: Exception) {
        }
        val raw = name ?: uri.lastPathSegment?.substringAfterLast('/') ?: "Comic"
        return raw.substringBeforeLast('.', raw)
    }

    private fun booksDir(context: Context) = File(context.filesDir, "books").apply { mkdirs() }
    private fun coversDir(context: Context) = File(context.filesDir, "covers").apply { mkdirs() }
    fun coverFile(context: Context, hash: String) = File(coversDir(context), "$hash.jpg")

    private fun remoteSize(context: Context, uri: Uri): Long {
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst() && !it.isNull(0)) return it.getLong(0)
            }
        } catch (_: Exception) {
        }
        return -1L
    }

    /** Makes sure a local copy of the file exists and returns it. */
    fun ensureCached(context: Context, uri: Uri, hash: String, status: (String) -> Unit): File {
        val target = File(booksDir(context), "$hash.bin")
        val size = remoteSize(context, uri)
        if (target.exists() && (size <= 0 || target.length() == size)) {
            target.setLastModified(System.currentTimeMillis())
            return target
        }
        try {
            status("Copying file…")
            val tmp = File(target.path + ".tmp")
            val input = context.contentResolver.openInputStream(uri) ?: throw IOException("Can't open the file.")
            input.use { src -> FileOutputStream(tmp).use { dst -> src.copyTo(dst) } }
            target.delete()
            if (!tmp.renameTo(target)) throw IOException("Can't save the file.")
        } catch (e: Exception) {
            // Permission to the original may be gone; fall back to an earlier copy if there is one.
            if (target.exists()) return target
            throw IOException("Can't open this file. Try opening it again with \"Open file\".")
        }
        evictOld(context, hash)
        return target
    }

    private fun evictOld(context: Context, keep: String) {
        val files = booksDir(context).listFiles { f -> f.name.endsWith(".bin") } ?: return
        files.sortedByDescending { it.lastModified() }
            .drop(MAX_CACHED_BOOKS)
            .filter { it.name != "$keep.bin" }
            .forEach { it.delete() }
    }

    /** Looks at the file's first bytes, so a mislabeled .cbz/.cbr still opens. */
    fun open(context: Context, hash: String, file: File, status: (String) -> Unit): ComicSource {
        val magic = ByteArray(4)
        file.inputStream().use { it.read(magic) }
        val isZip = magic[0] == 'P'.code.toByte() && magic[1] == 'K'.code.toByte()
        val isRar = magic[0] == 'R'.code.toByte() && magic[1] == 'a'.code.toByte() &&
            magic[2] == 'r'.code.toByte() && magic[3] == '!'.code.toByte()
        return when {
            isZip -> ZipSource(file)
            isRar -> openRar(context, hash, file, status)
            else -> throw IOException("Unsupported file. Expected a CBZ (ZIP) or CBR (RAR) archive.")
        }
    }

    private fun openRar(context: Context, hash: String, file: File, status: (String) -> Unit): ComicSource {
        // Only keep the extracted pages of the book being read.
        context.cacheDir.listFiles { f -> f.isDirectory && f.name.startsWith("rar_") && f.name != "rar_$hash" }
            ?.forEach { it.deleteRecursively() }

        val outDir = File(context.cacheDir, "rar_$hash")
        val done = File(outDir, ".done")
        val order = File(outDir, "order.txt")
        if (done.exists() && order.exists()) {
            val files = order.readLines().filter { it.isNotBlank() }.map { File(outDir, it) }.filter { it.exists() }
            if (files.isNotEmpty()) return FileListSource(files)
        }
        status("Preparing pages…")
        val files = RarExtractor.extract(file, outDir) { n -> status("Preparing pages… $n") }
        if (files.isEmpty()) throw IOException("No images found in this archive.")
        order.writeText(files.joinToString("\n") { it.name })
        done.writeText("ok")
        return FileListSource(files)
    }

    fun saveCoverIfMissing(context: Context, hash: String, source: ComicSource) {
        val cover = coverFile(context, hash)
        if (cover.exists()) return
        val bmp = source.decode(0, 360, 540) ?: return
        try {
            FileOutputStream(cover).use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        } finally {
            bmp.recycle()
        }
    }
}
